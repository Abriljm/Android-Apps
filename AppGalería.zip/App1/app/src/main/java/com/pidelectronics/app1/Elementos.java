package com.pidelectronics.app1;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Elementos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elementos);
    }
}