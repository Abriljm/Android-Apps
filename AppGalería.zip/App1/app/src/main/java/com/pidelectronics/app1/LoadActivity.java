package com.pidelectronics.app1;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class LoadActivity extends AppCompatActivity {

    TextView txtInfo;
    Timer timer, timer2;
    TextView versionName;

    @RequiresApi(api = Build.VERSION_CODES.P)
    private final String TAG = "Jaquez";
    @RequiresApi(api = Build.VERSION_CODES.P)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load);

        versionName = findViewById(R.id.txtLoadVersion);
        versionName.setText(BuildConfig.VERSION_NAME);

        setUpViews();
        Log.v(TAG, "onCreate");
        iniciarTimer();
        ChangeMain();
    }

    private void setUpViews() {
        txtInfo = findViewById(R.id.txtLoadInfo);
    }

    private void iniciarTimer(){
        timer= new Timer();
        timer.schedule(new TimerTask(){
            @RequiresApi(api = Build.VERSION_CODES.P)
            @Override
            public void run(){
                //Cuando pasen dos segundos se ejecuta run
                Log.w(TAG, "metodo run del timer ejecutado!");
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        //Este metodo ya se ejecuta en el hilo principal
                        txtInfo.setText("Iniciando App");
                    }
                });
            }
        }, 2000);
    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    private void ChangeMain(){
        timer2 = new Timer();
        timer2.schedule(new TimerTask(){
            @RequiresApi(api = Build.VERSION_CODES.P)
            @Override
            public void run(){
                Log.w(TAG, "metodo run del timer ejecutado!");
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        //Este metodo ya se ejecuta en el hilo principal
                        startActivity(new Intent(LoadActivity.this, LoginActivity.class));

                   }
                });
            }
        },4000);
    }
}