package com.pidelectronics.app1;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText edtUsuario, edtContra;
    Button btnAcceder;
    String usuario;
    String contra;
    String llave;
    private final String TAG="Jaquez";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setUpViews();
        Log.v(TAG, "onCreate");
        btnAcceder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                usuario = edtUsuario.getText().toString();
                contra = edtContra.getText().toString();
                if (usuario.isEmpty()){
                    Toast.makeText(LoginActivity.this, "Introduce un usuario", Toast.LENGTH_SHORT).show();
                }
                if (contra.isEmpty()){
                    Toast.makeText(LoginActivity.this, "Introduce una contraseña", Toast.LENGTH_SHORT).show();
                }
                else{
                    llave = recoverPassword(usuario);
                    if (llave.length() == 0){
                        signUp(usuario, contra);
                        logMain();
                    }else{
                        if(llave.equals(contra)){
                            logMain();
                        } else {
                            Toast.makeText(LoginActivity.this, "Contraseña incorrecta", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }

    private void setUpViews() {
        edtUsuario = findViewById(R.id.edtLogUsuario);
        edtContra = findViewById(R.id.edtLogContra);
        btnAcceder = findViewById(R.id.btnLogAcceder);
    }
    private void logMain() {
        startActivity(new Intent(LoginActivity.this, MainActivity.class));
    }

    private void signUp(String usuario, String contra) {
        SharedPreferences preferences = LoginActivity.this.getSharedPreferences("Login",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=preferences.edit();
        editor.putString(usuario,contra);
        editor.apply();

    }

    private String recoverPassword(String usuario) {
        SharedPreferences preferences = LoginActivity.this.getSharedPreferences("Login",Context.MODE_PRIVATE);
        return preferences.getString(usuario, "");
    }

}