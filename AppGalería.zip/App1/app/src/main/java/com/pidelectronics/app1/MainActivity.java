package com.pidelectronics.app1;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    Spinner spinner1;
    RadioGroup radioGroup;
    RadioButton radioButton;
    TextView txtInfo;
    EditText edtTelefono;
    Button btnLlamar;
    private final String TAG="Jaquez";
    String telefono;
    boolean permisollamadas = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner1 = (Spinner)findViewById(R.id.MainSpinner);
        radioGroup = (RadioGroup)findViewById(R.id.RGroup);

        String [] opciones = {"Pablo Picasso", "Claude Monet", "Vincent VanGogh",
        "Frida Kahlo", "Salvador Dalí", "Sandro Botticeli"};
        ArrayAdapter <String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, opciones);
        spinner1.setAdapter(adapter);
        setUpViews();
        Log.v(TAG, "onCreate");
    }

    @Override
    protected void onResume() {
        super.onResume();
        btnLlamar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                telefono = edtTelefono.getText().toString();
                if (telefono.isEmpty()){
                    Toast.makeText(MainActivity.this, "Favor de introducir el telefono", Toast.LENGTH_SHORT).show();
                }
                else{
                    revisarPermisos();
                }
            }
        });
    }

    private void setUpViews(){
        edtTelefono = findViewById(R.id.edtTelefono);
        btnLlamar = findViewById(R.id.btnMainLlamar);
    }

    private void revisarPermisos(){
        permisollamadas = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
        if (permisollamadas){
            realizarLlamada();
        }
        else{
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE},44);
        }
    }
    private void realizarLlamada(){
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + telefono));
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 44){
            permisollamadas = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
            if (permisollamadas)realizarLlamada();
            else Toast.makeText(MainActivity.this, "Permiso Rechazado", Toast.LENGTH_SHORT).show();
        }
    }

    public void SpinnerFunction (View v){
        String seleccion = spinner1.getSelectedItem().toString();
        if(seleccion.equals("Pablo Picasso")){
            //se va a otra ventana
        } else if(seleccion.equals("Claude Monet")){
            //Manda a la misma ventana, diferente info
        }else if(seleccion.equals("Vincent VanGogh")){
            //Lo mismo
        }else if(seleccion.equals("Frida Kahlo")){
            //Lo mismo
        }else if(seleccion.equals("Salvador Dalí")){
            //Lo mismo
        }else if(seleccion.equals("Sandro Botticeli")){
            //Lo mismo
        }
    }

public void rbclick(View v){
    int radiobuttonid = radioGroup.getCheckedRadioButtonId();
    radioButton = (RadioButton) findViewById(radiobuttonid);

    Toast.makeText(getBaseContext(), radioButton.getText(), Toast.LENGTH_SHORT).show();
}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menu_settings){
            Toast.makeText(this, "Settings", Toast.LENGTH_SHORT).show();
            AlertDialog.Builder aletra = new AlertDialog.Builder(MainActivity.this);
            aletra.setMessage("¿Seguro que desea cerrar sesión?")
                    .setCancelable(false)
                    .setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                        }
                    });
        } else {
            return super.onContextItemSelected(item);
        }
        return true;
    }
}